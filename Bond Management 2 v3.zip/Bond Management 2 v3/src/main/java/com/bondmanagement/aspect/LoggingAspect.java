package com.bondmanagement.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Aspect
@Component
public class LoggingAspect {
    private static Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    @Pointcut("execution(* com.bondmanagement.service.*.*(..))")
    public void serviceLog(){};

    @Before("serviceLog()")
    public void beforeAnyServiceMethod(JoinPoint joinPoint){
        logger.info(joinPoint.getSignature()+" going to executed with parameters "+ Arrays.toString(joinPoint.getArgs()));
    }

    @After("serviceLog()")
    public void afterAnyServiceMethod(JoinPoint joinPoint){
        logger.info(joinPoint.getSignature()+" is executed with parameters "+ Arrays.toString(joinPoint.getArgs()));
    }

//    @AfterThrowing(pointcut = "execution(* com.bondmanagement.service.PortfolioServiceImpl.getPortfolioByBondId(..))",throwing="ex")
//    public void getPortfolioByBondIdThrowing(JoinPoint joinPoint, Exception ex){
//        logger.error("Error at "+joinPoint.getSignature()+" "+ex.getMessage());
//    }
}
