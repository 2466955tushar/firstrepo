package com.bondmanagement.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.bondmanagement.dto.BondDto;
import com.bondmanagement.service.BondService;

@RestController
@RequestMapping("/bonds")
public class BondController {

    private final BondService bondService;

    public BondController(BondService bondService) {
        this.bondService = bondService;
    }

    @PostMapping
    public ResponseEntity<Void> addBond(@RequestBody BondDto bondDto) {
        bondService.addBond(bondDto);
        return ResponseEntity.status(201).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> updateBond(@PathVariable int id, @RequestBody BondDto bondDto) {
        bondService.updateBond(id, bondDto);
        return ResponseEntity.ok().build();
    }

    @GetMapping
    public ResponseEntity<List<BondDto>> getAllBonds() {
        return ResponseEntity.ok(bondService.getAllBonds());
    }

    @GetMapping("/{id}")
    public ResponseEntity<BondDto> getBondById(@PathVariable int id) {
        BondDto dto = bondService.getBondDetails(id);
        return dto == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(dto);
    }

    @GetMapping("/faceValue/{bondId}")
    public ResponseEntity<Double> findFaceValue(@PathVariable int bondId) {
        Double faceValue = bondService.findFaceValue(bondId);
        if (faceValue != null) {
            return ResponseEntity.ok(faceValue);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}