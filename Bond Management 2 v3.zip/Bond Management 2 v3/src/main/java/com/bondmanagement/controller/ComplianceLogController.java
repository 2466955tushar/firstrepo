package com.bondmanagement.controller;

import com.bondmanagement.dto.ComplianceLogDto;
import com.bondmanagement.service.ComplianceLogService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/compliance")
public class ComplianceLogController {

    private final ComplianceLogService complianceLogService;

    public ComplianceLogController(ComplianceLogService complianceLogService) {
        this.complianceLogService = complianceLogService;
    }

    @PutMapping("/validate-orders")
    public ResponseEntity<Void> validateOrder() {
        complianceLogService.validateOrder();
        return ResponseEntity.ok().build();
    }

    @PostMapping("/reports")
    public ResponseEntity<Void> generateComplianceReport(@RequestBody ComplianceLogDto complianceLogDto) {
        complianceLogService.generateComplianceReport(complianceLogDto);
        return ResponseEntity.status(201).build();
    }

    @GetMapping("/reports/{orderId}")
    public ResponseEntity<List<ComplianceLogDto>> getComplianceReport(@PathVariable int orderId) {
        return ResponseEntity.ok(complianceLogService.getComplianceReport(orderId));
    }
}