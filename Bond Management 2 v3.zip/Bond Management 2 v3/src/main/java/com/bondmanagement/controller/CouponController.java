package com.bondmanagement.controller;

import com.bondmanagement.dto.CouponDto;
import com.bondmanagement.service.CouponService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/coupons")
public class CouponController {

    private final CouponService couponService;

    public CouponController(CouponService couponService) {
        this.couponService = couponService;
    }

    @PostMapping("/schedule/{bondId}")
    public ResponseEntity<Void> schedule(@PathVariable int bondId) {
        couponService.scheduleCouponPayment(bondId);
        return ResponseEntity.status(201).build();
    }

    @GetMapping("/history/{bondId}")
    public ResponseEntity<List<CouponDto>> getCouponHistory(@PathVariable int bondId) {
        return ResponseEntity.ok(couponService.getCouponHistory(bondId));
    }
}