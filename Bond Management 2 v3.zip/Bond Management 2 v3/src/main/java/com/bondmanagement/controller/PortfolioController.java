package com.bondmanagement.controller;

import com.bondmanagement.dto.PortfolioDto;
import com.bondmanagement.service.PortfolioService;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/portfolios")
public class PortfolioController {

    private final PortfolioService portfolioService;

    public PortfolioController(PortfolioService portfolioService) {

        this.portfolioService = portfolioService;
    }

    @PostMapping
    public ResponseEntity<Void> addPortfolio(
            @RequestParam("bondId") int bondId,
            @RequestParam("userId") long userId,
            @RequestParam("qty") int quantity
    ) {
        portfolioService.addPortfolio(bondId, userId, quantity);
        return ResponseEntity.status(201).build();
    }

    @GetMapping
    public ResponseEntity<List<PortfolioDto>> getPortfolioByBondId(@RequestParam int bondId) {
        return ResponseEntity.ok(portfolioService.getPortfolioByBondId(bondId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> updatePortfolio(@PathVariable int id, @RequestBody PortfolioDto portfolioDto) {
        portfolioService.updatePortfolio(id, portfolioDto);
        return ResponseEntity.ok().build();
    }
}