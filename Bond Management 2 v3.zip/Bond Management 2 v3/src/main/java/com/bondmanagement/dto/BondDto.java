package com.bondmanagement.dto;

import jakarta.validation.constraints.*;

import java.time.LocalDate;
import java.util.List;

public class BondDto {

    private int bondId;

    @NotBlank
    private String issuer;

    @NotNull
    @DecimalMin(value = "100.00",message = "Minimum facevalue should be 100")
    private double faceValue;

    @NotNull
    @DecimalMax(value="40.00",message = "Max coupon rate will be 40.00")
    @DecimalMin(value="0.10",message = "Min coupon rate will be 0.10")
    private double couponRate;

    @NotNull
    @Future(message = "maturity date should be in future")
    private LocalDate maturityDate;

    public enum Status { ACTIVE, INACTIVE }

    @NotNull
    private Status status;

    private List<Integer> orderIds;
    private List<Integer> portfolioIds;
    private List<Integer> couponIds;

    public BondDto() {}

    public int getBondId() { return bondId; }
    public void setBondId(int bondId) { this.bondId = bondId; }

    public String getIssuer() { return issuer; }
    public void setIssuer(String issuer) { this.issuer = issuer; }

    public double getFaceValue() { return faceValue; }
    public void setFaceValue(double faceValue) { this.faceValue = faceValue; }

    public double getCouponRate() { return couponRate; }
    public void setCouponRate(double couponRate) { this.couponRate = couponRate; }

    public LocalDate getMaturityDate() { return maturityDate; }
    public void setMaturityDate(LocalDate maturityDate) { this.maturityDate = maturityDate; }

    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public List<Integer> getOrderIds() { return orderIds; }
    public void setOrderIds(List<Integer> orderIds) { this.orderIds = orderIds; }

    public List<Integer> getPortfolioIds() { return portfolioIds; }
    public void setPortfolioIds(List<Integer> portfolioIds) { this.portfolioIds = portfolioIds; }

    public List<Integer> getCouponIds() { return couponIds; }
    public void setCouponIds(List<Integer> couponIds) { this.couponIds = couponIds; }
}