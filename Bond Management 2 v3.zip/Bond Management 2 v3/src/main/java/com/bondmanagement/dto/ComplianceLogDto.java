package com.bondmanagement.dto;

public class ComplianceLogDto {

    private int logId;
    private String status;
    private String remarks;

    private int orderId;

    public ComplianceLogDto() {}

    public int getLogId() { return logId; }
    public void setLogId(int logId) { this.logId = logId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public int getOrderId() { return orderId; }
    public void setOrderId(int orderId) { this.orderId = orderId; }
}