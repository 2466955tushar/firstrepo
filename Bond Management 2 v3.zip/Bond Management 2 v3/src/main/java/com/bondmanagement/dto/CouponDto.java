package com.bondmanagement.dto;

import java.time.LocalDate;

public class CouponDto {

    private int couponId;
    private LocalDate paymentDate;
    private double amount;

    private int bondId;

    public CouponDto() {}

    public int getCouponId() { return couponId; }
    public void setCouponId(int couponId) { this.couponId = couponId; }

    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public int getBondId() { return bondId; }
    public void setBondId(int bondId) { this.bondId = bondId; }
}