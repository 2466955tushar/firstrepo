package com.bondmanagement.dto;

public class OrderDto {

    private int orderId;

    public enum OrderType { BUY, SELL }
    private OrderType orderType;

    private int quantity;
    private double price;

    public enum Status { PENDING, EXECUTED, CANCELLED }
    private Status status;

    private long userId;
    private int bondId;
    private Integer complianceLogId; // nullable

    public OrderDto() {}

    public int getOrderId() { return orderId; }
    public void setOrderId(int orderId) { this.orderId = orderId; }

    public OrderType getOrderType() { return orderType; }
    public void setOrderType(OrderType orderType) { this.orderType = orderType; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public long getUserId() { return userId; }
    public void setUserId(long userId) { this.userId = userId; }

    public int getBondId() { return bondId; }
    public void setBondId(int bondId) { this.bondId = bondId; }

    public Integer getComplianceLogId() { return complianceLogId; }
    public void setComplianceLogId(Integer complianceLogId) { this.complianceLogId = complianceLogId; }
}