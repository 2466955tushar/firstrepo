package com.bondmanagement.dto;

public class PortfolioDto {

    private int portfolioId;
    private int quantity;
    private double averagePrice;

    private long userId;
    private int bondId;

    public PortfolioDto() {}

    public int getPortfolioId() { return portfolioId; }
    public void setPortfolioId(int portfolioId) { this.portfolioId = portfolioId; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getAveragePrice() { return averagePrice; }
    public void setAveragePrice(double averagePrice) { this.averagePrice = averagePrice; }

    public long getUserId() { return userId; }
    public void setUserId(long userId) { this.userId = userId; }

    public int getBondId() { return bondId; }
    public void setBondId(int bondId) { this.bondId = bondId; }
}