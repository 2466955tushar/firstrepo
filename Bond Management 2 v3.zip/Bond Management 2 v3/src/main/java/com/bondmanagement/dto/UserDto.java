package com.bondmanagement.dto;

import java.util.List;

public class UserDto {

    public enum Role {
        ADMIN, TRADER, COMPLIANCE
    }

    private long userId;
    private String username;
    private Role role;

    private List<Integer> orderIds;
    private List<Integer> portfolioIds;

    public UserDto() {}

    public long getUserId() { return userId; }
    public void setUserId(long userId) { this.userId = userId; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }

    public List<Integer> getOrderIds() { return orderIds; }
    public void setOrderIds(List<Integer> orderIds) { this.orderIds = orderIds; }

    public List<Integer> getPortfolioIds() { return portfolioIds; }
    public void setPortfolioIds(List<Integer> portfolioIds) { this.portfolioIds = portfolioIds; }
}