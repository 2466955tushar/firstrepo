package com.bondmanagement.entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name = "Bond")
public class Bond {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int bondId;

    @Column(nullable = false)
    private String issuer;

    @Column(nullable = false)
    private double faceValue;

    @Column(nullable = false)
    private double couponRate;

    @Column(nullable = false)
    private LocalDate maturityDate;

    public enum Status { ACTIVE, INACTIVE }

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status;

    @OneToMany(mappedBy = "bond", fetch = FetchType.LAZY)
    private List<Order> orders;

    @OneToMany(mappedBy = "bond", fetch = FetchType.LAZY)
    private List<Portfolio> portfolios;

    @OneToMany(mappedBy = "bond", fetch = FetchType.LAZY)
    private List<Coupon> coupons;

    public Bond() {}

    public int getBondId() { return bondId; }
    public void setBondId(int bondId) { this.bondId = bondId; }

    public String getIssuer() { return issuer; }
    public void setIssuer(String issuer) { this.issuer = issuer; }

    public double getFaceValue() { return faceValue; }
    public void setFaceValue(double faceValue) { this.faceValue = faceValue; }

    public double getCouponRate() { return couponRate; }
    public void setCouponRate(double couponRate) { this.couponRate = couponRate; }

    public LocalDate getMaturityDate() { return maturityDate; }
    public void setMaturityDate(LocalDate maturityDate) { this.maturityDate = maturityDate; }

    // FIX: return entity enum type, not DTO enum type
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public List<Order> getOrders() { return orders; }
    public void setOrders(List<Order> orders) { this.orders = orders; }

    public List<Portfolio> getPortfolios() { return portfolios; }
    public void setPortfolios(List<Portfolio> portfolios) { this.portfolios = portfolios; }

    public List<Coupon> getCoupons() { return coupons; }
    public void setCoupons(List<Coupon> coupons) { this.coupons = coupons; }

    @Override
    public String toString() {
        return "Bond[bondId=" + bondId +
                ", issuer=" + issuer +
                ", faceValue=" + faceValue +
                ", couponRate=" + couponRate +
                ", maturityDate=" + maturityDate +
                ", status=" + status + "]";
    }
}