package com.bondmanagement.entity;

import java.time.LocalDate;

import jakarta.persistence.*;

@Entity
@Table(name = "Coupon")
public class Coupon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int couponId;

    @Column(nullable = false)
    private LocalDate paymentDate;

    @Column(nullable = false)
    private double amount;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "bondId", nullable = false)
    private Bond bond;

    /*
        paymentdate:"",
        amoubt:,
        bond:{
            bond id:,
            issuer:,

        }
    */
    public Coupon() {}

    public int getCouponId() { return couponId; }
    public void setCouponId(int couponId) { this.couponId = couponId; }

    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public Bond getBond() { return bond; }
    public void setBond(Bond bond) { this.bond = bond; }

    @Override
    public String toString() {
        return "Coupon[couponId=" + couponId +
                ", paymentDate=" + paymentDate +
                ", amount=" + amount + "]";
    }
}