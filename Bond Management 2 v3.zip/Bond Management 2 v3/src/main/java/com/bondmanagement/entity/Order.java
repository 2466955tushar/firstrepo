package com.bondmanagement.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "Orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "bond_id", nullable = false)
    private Bond bond;

    public enum OrderType { BUY, SELL }

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private OrderType orderType;

    @Column(nullable = false)
    private int quantity;

    @Column(nullable = false)
    private double price;

    public enum Status { PENDING, EXECUTED, CANCELLED }

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status;

    @OneToOne(mappedBy = "order", fetch = FetchType.LAZY)
    private ComplianceLog complianceLog;

    public Order() {}

    public int getOrderId() { return orderId; }
    public void setOrderId(int orderId) { this.orderId = orderId; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Bond getBond() { return bond; }
    public void setBond(Bond bond) { this.bond = bond; }

    public OrderType getOrderType() { return orderType; }
    public void setOrderType(OrderType orderType) { this.orderType = orderType; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public ComplianceLog getComplianceLog() { return complianceLog; }
    public void setComplianceLog(ComplianceLog complianceLog) { this.complianceLog = complianceLog; }

    @Override
    public String toString() {
        return "Order[orderId=" + orderId +
                ", orderType=" + orderType +
                ", quantity=" + quantity +
                ", price=" + price +
                ", status=" + status + "]";
    }
}