package com.bondmanagement.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "Portfolio")
public class Portfolio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int portfolioId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "userId", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "bondId", nullable = false)
    private Bond bond;

    @Column(nullable = false)
    private int quantity;

    @Column(nullable = false)
    private double averagePrice;

    public Portfolio() {}

    public int getPortfolioId() { return portfolioId; }
    public void setPortfolioId(int portfolioId) { this.portfolioId = portfolioId; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Bond getBond() { return bond; }
    public void setBond(Bond bond) { this.bond = bond; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getAveragePrice() { return averagePrice; }
    public void setAveragePrice(double averagePrice) { this.averagePrice = averagePrice; }

    @Override
    public String toString() {
        return "Portfolio[portfolioId=" + portfolioId +
                ", quantity=" + quantity +
                ", averagePrice=" + averagePrice + "]";
    }
}