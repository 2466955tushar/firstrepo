package com.bondmanagement.exception;

public class BondNotFoundException extends RuntimeException{
    public BondNotFoundException(int bondId){
        super("Bond Not Found for Bond Id:"+bondId);
    }
}
