package com.bondmanagement.exception;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import jakarta.servlet.http.HttpServletRequest;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(Exception.class)
    public String handleAnyException(Exception ex, HttpServletRequest request, Model model) {
        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("error", ex.getClass().getSimpleName());
        model.addAttribute("message", ex.getMessage());
        return "error/global-error";
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public String handleDbException(DataIntegrityViolationException ex, HttpServletRequest request, Model model) {
        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("error", "Database Error");
        model.addAttribute("message", "Operation failed due to database constraints.");
        return "error/global-error";
    }
}
