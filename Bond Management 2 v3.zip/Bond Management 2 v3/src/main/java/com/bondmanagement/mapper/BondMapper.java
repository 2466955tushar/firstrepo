package com.bondmanagement.mapper;

import com.bondmanagement.dto.BondDto;
import com.bondmanagement.entity.Bond;

public final class BondMapper {
    private BondMapper() {}

    public static Bond toEntity(BondDto dto) {
        if (dto == null) return null;

        Bond e = new Bond();
        e.setBondId(dto.getBondId());
        e.setIssuer(dto.getIssuer());
        e.setFaceValue(dto.getFaceValue());
        e.setCouponRate(dto.getCouponRate());
        e.setMaturityDate(dto.getMaturityDate());

        if (dto.getStatus() != null) {
            e.setStatus(Bond.Status.valueOf(dto.getStatus().name()));
        } else {
            e.setStatus(Bond.Status.ACTIVE);
        }

        return e;
    }

    public static BondDto toDto(Bond e) {
        if (e == null) return null;

        BondDto dto = new BondDto();
        dto.setBondId(e.getBondId());
        dto.setIssuer(e.getIssuer());
        dto.setFaceValue(e.getFaceValue());
        dto.setCouponRate(e.getCouponRate());
        dto.setMaturityDate(e.getMaturityDate());

        // convert Bond.Status -> BondDto.Status
        if (e.getStatus() != null) {
            dto.setStatus(BondDto.Status.valueOf(e.getStatus().name()));
        }

        return dto;
    }
}