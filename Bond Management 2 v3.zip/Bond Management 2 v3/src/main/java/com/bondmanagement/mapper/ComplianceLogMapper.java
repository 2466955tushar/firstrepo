package com.bondmanagement.mapper;

import com.bondmanagement.dto.ComplianceLogDto;
import com.bondmanagement.entity.ComplianceLog;
import com.bondmanagement.entity.Order;

public final class ComplianceLogMapper {
    private ComplianceLogMapper() {}

    public static ComplianceLog toEntity(ComplianceLogDto dto) {
        if (dto == null) return null;

        ComplianceLog e = new ComplianceLog();
        e.setLogId(dto.getLogId());
        e.setStatus(dto.getStatus());
        e.setRemarks(dto.getRemarks());

        Order order = new Order();
        order.setOrderId(dto.getOrderId());
        e.setOrder(order);

        return e;
    }

    public static ComplianceLogDto toDto(ComplianceLog e) {
        if (e == null) return null;

        ComplianceLogDto dto = new ComplianceLogDto();
        dto.setLogId(e.getLogId());
        dto.setStatus(e.getStatus());
        dto.setRemarks(e.getRemarks());
        dto.setOrderId(e.getOrder() != null ? e.getOrder().getOrderId() : 0);

        return dto;
    }
}