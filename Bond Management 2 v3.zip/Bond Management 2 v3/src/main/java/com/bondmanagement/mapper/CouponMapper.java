package com.bondmanagement.mapper;

import com.bondmanagement.dto.CouponDto;
import com.bondmanagement.entity.Bond;
import com.bondmanagement.entity.Coupon;

public final class CouponMapper {
    private CouponMapper() {}

    public static Coupon toEntity(CouponDto dto) {
        if (dto == null) return null;

        Coupon e = new Coupon();
        e.setCouponId(dto.getCouponId());
        e.setPaymentDate(dto.getPaymentDate());
        e.setAmount(dto.getAmount());

        Bond b = new Bond();
        b.setBondId(dto.getBondId());
        e.setBond(b);

        return e;
    }

    public static CouponDto toDto(Coupon e) {
        if (e == null) return null;

        CouponDto dto = new CouponDto();
        dto.setCouponId(e.getCouponId());
        dto.setPaymentDate(e.getPaymentDate());
        dto.setAmount(e.getAmount());
        dto.setBondId(e.getBond() != null ? e.getBond().getBondId() : 0);
        return dto;
    }
}