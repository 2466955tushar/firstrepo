package com.bondmanagement.mapper;

import com.bondmanagement.dto.OrderDto;
import com.bondmanagement.entity.Bond;
import com.bondmanagement.entity.Order;
import com.bondmanagement.entity.User;

public final class OrderMapper {
    private OrderMapper() {}

    public static Order toEntity(OrderDto dto) {
        if (dto == null) return null;

        Order e = new Order();
        e.setOrderId(dto.getOrderId());
        e.setOrderType(dto.getOrderType() == null ? Order.OrderType.BUY : Order.OrderType.valueOf(dto.getOrderType().name()));
        e.setQuantity(dto.getQuantity());
        e.setPrice(dto.getPrice());
        e.setStatus(dto.getStatus() == null ? Order.Status.PENDING : Order.Status.valueOf(dto.getStatus().name()));

        // shallow relationships: set only IDs
        User u = new User();
        u.setUserId(dto.getUserId());
        e.setUser(u);

        Bond b = new Bond();
        b.setBondId(dto.getBondId());
        e.setBond(b);

        return e;
    }

    public static OrderDto toDto(Order e) {
        if (e == null) return null;

        OrderDto dto = new OrderDto();
        dto.setOrderId(e.getOrderId());
        dto.setOrderType(e.getOrderType() == null ? null : OrderDto.OrderType.valueOf(e.getOrderType().name()));
        dto.setQuantity(e.getQuantity());
        dto.setPrice(e.getPrice());
        dto.setStatus(e.getStatus() == null ? null : OrderDto.Status.valueOf(e.getStatus().name()));

        dto.setUserId(e.getUser() != null ? e.getUser().getUserId() : 0L);
        dto.setBondId(e.getBond() != null ? e.getBond().getBondId() : 0);

        dto.setComplianceLogId(e.getComplianceLog() != null ? e.getComplianceLog().getLogId() : null);
        return dto;
    }
}