package com.bondmanagement.mapper;

import com.bondmanagement.dto.PortfolioDto;
import com.bondmanagement.entity.Portfolio;

public final class PortfolioMapper {
    private PortfolioMapper() {}

    public static PortfolioDto toDto(Portfolio e) {
        if (e == null) return null;

        PortfolioDto dto = new PortfolioDto();
        dto.setPortfolioId(e.getPortfolioId());
        dto.setQuantity(e.getQuantity());
        dto.setAveragePrice(e.getAveragePrice());

        dto.setUserId(e.getUser() != null ? e.getUser().getUserId() : 0L);
        dto.setBondId(e.getBond() != null ? e.getBond().getBondId() : 0);

        return dto;
    }
}