package com.bondmanagement.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.bondmanagement.entity.Bond;

@Repository
public interface BondRepository extends JpaRepository<Bond, Integer> {

    @Query("select b.faceValue from Bond b where b.bondId = :bondId")
    Optional<Double> findFaceValueByBondId(@Param("bondId") int bondId);
}