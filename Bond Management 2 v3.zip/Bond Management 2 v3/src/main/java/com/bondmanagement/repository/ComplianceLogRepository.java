package com.bondmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bondmanagement.entity.ComplianceLog;

import java.util.List;

@Repository
public interface ComplianceLogRepository extends JpaRepository<ComplianceLog, Integer> {
    List<ComplianceLog> findByOrder_OrderId(int orderId);
}