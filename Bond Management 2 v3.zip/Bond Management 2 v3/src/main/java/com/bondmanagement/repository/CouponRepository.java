package com.bondmanagement.repository;

import java.util.Arrays;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bondmanagement.entity.Coupon;

@Repository
public interface CouponRepository extends JpaRepository<Coupon, Integer> {
    void deleteByBond_BondId(int bondId);
    List<Coupon> findByBond_BondId(int bondId);

    @Query("SELECT c FROM Coupon c WHERE c.bond.bondId IN :bondIds")
    List<Coupon> findByBondIds(@Param("bondIds") List<Integer> bondIds);

}