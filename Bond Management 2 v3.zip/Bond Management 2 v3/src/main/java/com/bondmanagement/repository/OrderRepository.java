package com.bondmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bondmanagement.entity.Order;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {

    @Query("SELECT o.status FROM Order o WHERE o.orderId = :orderId")
    Order.Status findStatusByOrderId(@Param("orderId") int orderId);

    @Query("SELECT o.status FROM Order o WHERE o.bond.bondId = :bondId")
    Order.Status findStatusByBondId(@Param("bondId") int bondId);

    List<Order> findByStatus(Order.Status status);

    // find order by userId
    List<Order> findByUser_UserId(long userId);
    Optional<Order> findByUser_UserIdAndOrderId(long userId, int orderId);

}