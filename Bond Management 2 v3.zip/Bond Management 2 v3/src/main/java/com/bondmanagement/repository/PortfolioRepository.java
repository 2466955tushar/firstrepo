package com.bondmanagement.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bondmanagement.entity.Portfolio;

@Repository
public interface PortfolioRepository extends JpaRepository<Portfolio, Integer> {
    List<Portfolio> findByBond_BondId(int bondId);
    Optional<Portfolio> findByUser_UserIdAndBond_BondId(long userId, int bondId);
}