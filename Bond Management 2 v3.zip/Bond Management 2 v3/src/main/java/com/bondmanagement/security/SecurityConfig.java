package com.bondmanagement.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/static/**", "/js/**", "/images/**", "/webjars/**").permitAll()
                .requestMatchers("/login").permitAll()

                .requestMatchers("/", "/ui").authenticated()

                // ✅ Bonds: view allowed for ADMIN + TRADER
                .requestMatchers(HttpMethod.GET, "/ui/bonds", "/ui/bonds/").hasAnyRole("ADMIN", "TRADER")

                // ✅ Bonds: create/update only ADMIN
                .requestMatchers(HttpMethod.GET, "/ui/bonds/new").hasRole("ADMIN")
                .requestMatchers(HttpMethod.POST, "/ui/bonds").hasRole("ADMIN")
                .requestMatchers(HttpMethod.GET, "/ui/bonds/*/edit").hasRole("ADMIN")
                .requestMatchers(HttpMethod.POST, "/ui/bonds/*").hasRole("ADMIN")

                // Orders/Portfolio (TRADER)
                .requestMatchers("/ui/orders/**").hasRole("TRADER")
                .requestMatchers("/ui/portfolios/**").hasRole("TRADER")

                // Coupons: view ADMIN+TRADER, schedule ADMIN only
                .requestMatchers(HttpMethod.POST, "/ui/coupons/schedule").hasRole("ADMIN")
                .requestMatchers("/ui/coupons/**").hasAnyRole("TRADER", "ADMIN")

                // Compliance
                .requestMatchers("/ui/compliance/**").hasRole("COMPLIANCE")

                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .successHandler((request, response, authentication) -> {
                    var authorities = authentication.getAuthorities();
                    String redirectUrl = "/ui"; // fallback
//                    if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_COMPLIANCE")))
//                    { redirectUrl = "/ui/compliance"; }
//                    else if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_TRADER")))
//                    { redirectUrl = "/ui/orders/new"; }
//                    else if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN")))
//                    { redirectUrl = "/ui/bonds"; }
                    response.sendRedirect(redirectUrl);
                })
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout")
            )
            .exceptionHandling(eh -> eh.accessDeniedPage("/access-denied"))
            .httpBasic(Customizer.withDefaults());

        return http.build();
    }
}