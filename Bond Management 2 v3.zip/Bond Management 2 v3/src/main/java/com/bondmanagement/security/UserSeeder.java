package com.bondmanagement.security;

import com.bondmanagement.entity.User;
import com.bondmanagement.entity.User.Role;
import com.bondmanagement.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class UserSeeder {

    @Bean
    CommandLineRunner seedUsers(UserRepository userRepository, PasswordEncoder encoder) {
        return args -> {
            createIfMissing(userRepository, encoder, "admin", "admin123", Role.ADMIN);
            createIfMissing(userRepository, encoder, "trader", "trader123", Role.TRADER);
            createIfMissing(userRepository, encoder, "compliance", "compliance123", Role.COMPLIANCE);
        };
    }

    private void createIfMissing(UserRepository repo, PasswordEncoder encoder,
                                 String username, String rawPassword, Role role) {

        if (repo.findByUsername(username).isPresent()) return;

        User u = new User();
        u.setUsername(username);
        u.setPassword(encoder.encode(rawPassword));
        u.setRole(role);
        repo.save(u);
    }
}