package com.bondmanagement.service;

import java.util.List;

import com.bondmanagement.dto.BondDto;

public interface BondService {
    void addBond(BondDto bondDto);
    void updateBond(int id, BondDto bondDto);
    BondDto getBondDetails(int id);
    List<BondDto> getAllBonds();
    boolean bondExists(int bondId);
    Double findFaceValue(int bondId);
}