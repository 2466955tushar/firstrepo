package com.bondmanagement.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bondmanagement.dto.BondDto;
import com.bondmanagement.entity.Bond;
import com.bondmanagement.mapper.BondMapper;
import com.bondmanagement.repository.BondRepository;

@Service
public class BondServiceImpl implements BondService {

    private final BondRepository bondRepository;
    private final CouponService couponService;

    public BondServiceImpl(BondRepository bondRepository, CouponService couponService) {
        this.bondRepository = bondRepository;
        this.couponService = couponService;
    }

    @Override
    @Transactional
    public void addBond(BondDto bondDto) {
        Bond saved = bondRepository.save(BondMapper.toEntity(bondDto));
        couponService.scheduleCouponPayment(saved.getBondId());
    }

    @Override
    @Transactional
    public void updateBond(int id, BondDto bondDto) {
        Bond existing = bondRepository.findById(id).orElse(null);
        if (existing == null) return;

        boolean scheduleChanged =
                Double.compare(existing.getFaceValue(), bondDto.getFaceValue()) != 0
                        || Double.compare(existing.getCouponRate(), bondDto.getCouponRate()) != 0
                        || (bondDto.getMaturityDate() != null && !bondDto.getMaturityDate().equals(existing.getMaturityDate()));

        if (bondDto.getIssuer() != null) existing.setIssuer(bondDto.getIssuer());
        if (bondDto.getMaturityDate() != null) existing.setMaturityDate(bondDto.getMaturityDate());
        existing.setFaceValue(bondDto.getFaceValue());
        existing.setCouponRate(bondDto.getCouponRate());
        if (bondDto.getStatus() != null) {
            existing.setStatus(Bond.Status.valueOf(bondDto.getStatus().name()));
        }

        bondRepository.save(existing);

        if (scheduleChanged) {
            couponService.deleteCoupons(id);
            couponService.scheduleCouponPayment(id);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public BondDto getBondDetails(int id) {
        return bondRepository.findById(id).map(BondMapper::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BondDto> getAllBonds() {
        return bondRepository.findAll().stream().map(BondMapper::toDto).toList();
    }

    @Override
    public boolean bondExists(int bondId) {
        return bondRepository.existsById(bondId);
    }

    @Override
    public Double findFaceValue(int bondId) {
        return bondRepository.findFaceValueByBondId(bondId).orElse(null);
    }
}