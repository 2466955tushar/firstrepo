package com.bondmanagement.service;

import com.bondmanagement.dto.ComplianceLogDto;
import com.bondmanagement.entity.Order;

import java.util.List;

public interface ComplianceLogService {
	void validateOrder();
	void generateComplianceReport(ComplianceLogDto complianceLogDto);
    List<ComplianceLogDto> getComplianceReport(int orderId);
    List<ComplianceLogDto> getAllLogs();
    void executeOrder(int logId);
    void rejectOrder(int logId);

    List<Order> getPendingOrders();

    Order getOrderById(int orderId);
}