package com.bondmanagement.service;

import com.bondmanagement.dto.ComplianceLogDto;
import com.bondmanagement.entity.ComplianceLog;
import com.bondmanagement.entity.Order;
import com.bondmanagement.mapper.ComplianceLogMapper;
import com.bondmanagement.repository.ComplianceLogRepository;
import com.bondmanagement.repository.OrderRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ComplianceLogServiceImpl implements ComplianceLogService {

    private final ComplianceLogRepository complianceLogRepository;
    private final OrderService orderService;
    private final OrderRepository orderRepository;
    private final BondService bondService;
    private final UserService userService;
    private final PortfolioService portfolioService;

    public ComplianceLogServiceImpl(
            ComplianceLogRepository complianceLogRepository,
            OrderService orderService,
            OrderRepository orderRepository,
            BondService bondService,
            UserService userService,
            PortfolioService portfolioService
    ) {
        this.complianceLogRepository = complianceLogRepository;
        this.orderService = orderService;
        this.orderRepository = orderRepository;
        this.bondService = bondService;
        this.userService = userService;
        this.portfolioService = portfolioService;
    }

    @Override
    @Transactional
    public void validateOrder() {
        List<Order> orders = orderService.findByStatus(Order.Status.PENDING);

        for (Order order : orders) {
            if (order.getBond() == null || order.getUser() == null) {
                orderService.deleteOrder(order);
                continue;
            }

            int bondId = order.getBond().getBondId();
            long userId = order.getUser().getUserId();

            boolean ok = bondService.bondExists(bondId) && userService.existUser((int) userId);

            if (!ok) {
                orderService.deleteOrder(order);
                continue;
            }

            // Execute order
            order.setStatus(Order.Status.EXECUTED);
            orderRepository.save(order);

            // Update portfolio for BUY only (SELL logic would reduce holdings)
            if (order.getOrderType() == Order.OrderType.BUY) {
                portfolioService.applyBuyTrade(bondId, userId, order.getQuantity(), order.getPrice());
            }
            else if (order.getOrderType() == Order.OrderType.SELL) {
                portfolioService.applySellTrade(bondId, userId, order.getQuantity(), order.getPrice());
            }

            // Optional: create compliance log entry
            ComplianceLog log = new ComplianceLog();
            log.setOrder(order);
            log.setStatus("VALIDATED");
            log.setRemarks("Order executed by compliance validation");
            complianceLogRepository.save(log);
        }
    }

    @Override
    @Transactional
    public void generateComplianceReport(ComplianceLogDto complianceLogDto) {
        complianceLogRepository.save(ComplianceLogMapper.toEntity(complianceLogDto));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ComplianceLogDto> getComplianceReport(int orderId) {
        return complianceLogRepository.findByOrder_OrderId(orderId)
                .stream()
                .map(ComplianceLogMapper::toDto)
                .toList();
    }


    // to get all the logs
    @Override
    @Transactional(readOnly = true)
    public List<ComplianceLogDto> getAllLogs() {
        return complianceLogRepository.findAll()
                .stream()
                .map(ComplianceLogMapper::toDto)
                .toList();
    }
//  Execute order
@Transactional
public void executeOrder(int orderId) {
    Order order = orderRepository.findById(orderId).orElseThrow();
    order.setStatus(Order.Status.EXECUTED);
    orderRepository.save(order);

    // update portfolio
    if (order.getOrderType() == Order.OrderType.BUY) {
        portfolioService.applyBuyTrade(order.getBond().getBondId(), order.getUser().getUserId(),
                order.getQuantity(), order.getPrice());
    } else {
        portfolioService.applySellTrade(order.getBond().getBondId(), order.getUser().getUserId(),
                order.getQuantity(), order.getPrice());
    }

    // create compliance log entry
    ComplianceLog log = new ComplianceLog();
    log.setOrder(order);
    log.setStatus("Validated");
    log.setRemarks("Order Executed Compliance Officer");
    complianceLogRepository.save(log);
}

    @Transactional
    public void rejectOrder(int orderId) {
        Order order = orderRepository.findById(orderId).orElseThrow();
        order.setStatus(Order.Status.CANCELLED);
        orderRepository.save(order);

        ComplianceLog log = new ComplianceLog();
        log.setOrder(order);
        log.setStatus("Rejected");
        log.setRemarks("Order cancelled By Compliance Officer");
        complianceLogRepository.save(log);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Order> getPendingOrders() {
        return orderService.findByStatus(Order.Status.PENDING);
    }

    @Override
    public Order getOrderById(int orderId) {
        return orderService.findById(orderId);
    }
}