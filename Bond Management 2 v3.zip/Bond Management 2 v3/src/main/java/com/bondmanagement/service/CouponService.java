package com.bondmanagement.service;

import java.util.List;

import com.bondmanagement.dto.CouponDto;

public interface CouponService {
    void scheduleCouponPayment(int bondId);
    List<CouponDto> getCouponHistory(int bondId);
    void deleteCoupons(int bondId);
// to get all coupons for user
    List<CouponDto> getAllCouponsForUser(long userId);

}