package com.bondmanagement.service;

import java.time.LocalDate;
import java.util.List;

import com.bondmanagement.entity.Order;
import com.bondmanagement.repository.OrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bondmanagement.dto.CouponDto;
import com.bondmanagement.entity.Bond;
import com.bondmanagement.entity.Coupon;
import com.bondmanagement.mapper.CouponMapper;
import com.bondmanagement.repository.BondRepository;
import com.bondmanagement.repository.CouponRepository;

@Service
public class CouponServiceImpl implements CouponService {

    private final CouponRepository couponRepository;
    private final BondRepository bondRepository;
    private final OrderRepository orderRepository;

    public CouponServiceImpl(CouponRepository couponRepository, BondRepository bondRepository,OrderRepository orderRepository) {
        this.couponRepository = couponRepository;
        this.bondRepository = bondRepository;
        this.orderRepository = orderRepository;
    }

    private Coupon generateCoupon(Bond bond, LocalDate paymentDate) {
        Coupon coupon = new Coupon();
        coupon.setBond(bond);
        coupon.setAmount(bond.getCouponRate() / 100.0 * bond.getFaceValue());
        coupon.setPaymentDate(paymentDate);
        return coupon;
    }

    @Override
    @Transactional
    public void scheduleCouponPayment(int bondId) {
        Bond bond = bondRepository.findById(bondId).orElse(null);
        if (bond == null) return;

        LocalDate maturityDate = bond.getMaturityDate();
        if (maturityDate == null) return;

        // Simple annual schedule: from next year until maturity
        LocalDate nextPayment = LocalDate.now().plusYears(1);
        while (!nextPayment.isAfter(maturityDate)) {
            couponRepository.save(generateCoupon(bond, nextPayment)); // FIX: use nextPayment
            nextPayment = nextPayment.plusYears(1);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<CouponDto> getCouponHistory(int bondId) {
        return couponRepository.findByBond_BondId(bondId).stream()
                .map(CouponMapper::toDto)
                .toList();
    }

    @Override
    @Transactional
    public void deleteCoupons(int bondId) {
        couponRepository.deleteByBond_BondId(bondId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CouponDto> getAllCouponsForUser(long userId) {
        // Get all orders for the user

        List<Order> orders = orderRepository.findByUser_UserId(userId);

        // Extract bond IDs
        List<Integer> bondIds = orders.stream()
                .map(o -> o.getBond().getBondId())
                .distinct()
                .toList();

        // Fetch coupons for all those bonds
        return couponRepository.findByBondIds(bondIds).stream()
                .map(CouponMapper::toDto)
                .toList();
    }


}