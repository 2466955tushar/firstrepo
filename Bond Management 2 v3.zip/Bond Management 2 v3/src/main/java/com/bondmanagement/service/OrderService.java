package com.bondmanagement.service;

import com.bondmanagement.dto.OrderDto;
import com.bondmanagement.entity.Order;

import java.util.List;

public interface OrderService {
	void placeOrder(OrderDto orderDto);
	void cancelOrder(int id);
	String getOrderStatus(int id);
    List<Order> findByStatus(Order.Status pending);
    void deleteOrder(Order order);

    List<Order> findByUserId(long userId);
    OrderDto findByUserIdAndOrderId(long userId, int orderId);
    Order findById(int orderId);
}
