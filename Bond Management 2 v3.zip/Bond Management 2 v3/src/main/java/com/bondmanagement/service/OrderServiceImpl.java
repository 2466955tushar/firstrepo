package com.bondmanagement.service;

import com.bondmanagement.exception.OrderNotFoundException;
import com.bondmanagement.repository.BondRepository;
import com.bondmanagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bondmanagement.dto.OrderDto;
import com.bondmanagement.entity.Order;
import com.bondmanagement.mapper.OrderMapper;
import com.bondmanagement.repository.OrderRepository;

import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;

    public OrderServiceImpl(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    @Override
    @Transactional
    public void placeOrder(OrderDto orderDto) {
        orderDto.setStatus(OrderDto.Status.PENDING);

        Order order = OrderMapper.toEntity(orderDto);
        order.setStatus(Order.Status.PENDING);

        orderRepository.save(order);
    }

    @Override
    @Transactional
    public void cancelOrder(int id) {
        Order order = orderRepository.findById(id).orElse(null);
        if (order == null) return;

        if (order.getStatus() != Order.Status.CANCELLED) {
            order.setStatus(Order.Status.CANCELLED);
            orderRepository.save(order);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public String getOrderStatus(int id) {
        Order.Status status = orderRepository.findStatusByOrderId(id); // FIX
        return status != null ? status.name() : null;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Order> findByStatus(Order.Status status) {
        return orderRepository.findByStatus(status);
    }

    @Override
    @Transactional
    public void deleteOrder(Order order) {
        orderRepository.delete(order);
    }

    // find orders by user id
    @Override
    @Transactional(readOnly = true)
    public List<Order> findByUserId(long userId) {
        return orderRepository.findByUser_UserId(userId);
    }

    @Override
    @Transactional(readOnly = true)
    public OrderDto findByUserIdAndOrderId(long userId, int orderId) {
        Optional<Order> order = orderRepository.findByUser_UserIdAndOrderId(userId, orderId);

        if(order.isEmpty()){
            throw new OrderNotFoundException(orderId);
        }

        return order
                .map(OrderMapper::toDto)
                .orElse(null);
    }

    @Override
    public Order findById(int orderId) {
        Optional<Order> order = orderRepository.findById(orderId);
        return order.orElse(null);
    }

}