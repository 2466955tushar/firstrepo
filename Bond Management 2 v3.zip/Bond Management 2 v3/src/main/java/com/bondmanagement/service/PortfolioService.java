package com.bondmanagement.service;

import java.util.List;

import com.bondmanagement.dto.PortfolioDto;

public interface PortfolioService {
    void addPortfolio(int bondId, long userId, int quantity);
    void applyBuyTrade(int bondId, long userId, int quantity, double price);
    void applySellTrade(int bondId, long userId, int quantity, double price);
    List<PortfolioDto> getPortfolioByBondId(int bondId);
    void updatePortfolio(int id, PortfolioDto portfolioDto);

//    new added
    List<PortfolioDto> getAllPortfolios();

}