package com.bondmanagement.service;

import java.util.List;

import com.bondmanagement.exception.BondNotFoundException;
import jakarta.validation.constraints.Null;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bondmanagement.dto.PortfolioDto;
import com.bondmanagement.entity.Bond;
import com.bondmanagement.entity.Portfolio;
import com.bondmanagement.entity.User;
import com.bondmanagement.mapper.PortfolioMapper;
import com.bondmanagement.repository.BondRepository;
import com.bondmanagement.repository.PortfolioRepository;
import com.bondmanagement.repository.UserRepository;

@Service
public class PortfolioServiceImpl implements PortfolioService {

    private final PortfolioRepository portfolioRepository;
    private final BondRepository bondRepository;
    private final UserRepository userRepository;

    public PortfolioServiceImpl(PortfolioRepository portfolioRepository, BondRepository bondRepository, UserRepository userRepository) {
        this.portfolioRepository = portfolioRepository;
        this.bondRepository = bondRepository;
        this.userRepository = userRepository;
    }

    @Override
    @Transactional
    public void addPortfolio(int bondId, long userId, int quantity) {
        applyBuyTrade(bondId, userId, quantity, /*fallback price*/ bondRepository.findById(bondId).map(Bond::getFaceValue).orElse(0.0));
    }

    @Override
    @Transactional
    public void applyBuyTrade(int bondId, long userId, int quantity, double price) {
        if (quantity <= 0) return;

        Bond bond = bondRepository.findById(bondId).orElse(null);
        User user = userRepository.findById(userId).orElse(null);
        if (bond == null || user == null) return;

        Portfolio portfolio = portfolioRepository.findByUser_UserIdAndBond_BondId(userId, bondId)
                .orElseGet(() -> {
                    Portfolio p = new Portfolio();
                    p.setBond(bond);
                    p.setUser(user);
                    p.setQuantity(0);
                    p.setAveragePrice(0.0);
                    return p;
                });

        int oldQty = portfolio.getQuantity();
        double oldAvg = portfolio.getAveragePrice();

        int newQty = oldQty + quantity;
        double newAvg = (oldQty == 0)
                ? price
                : ((oldAvg * oldQty) + (price * quantity)) / newQty;

        portfolio.setQuantity(newQty);
        portfolio.setAveragePrice(newAvg);

        portfolioRepository.save(portfolio);
    }

    @Override
    @Transactional
    public void applySellTrade(int bondId, long userId, int quantity, double price) {
        if (quantity <= 0) return;

        Bond bond = bondRepository.findById(bondId).orElse(null);
        User user = userRepository.findById(userId).orElse(null);

        if (bond == null || user == null) return;

        Portfolio portfolio = portfolioRepository.findByUser_UserIdAndBond_BondId(userId, bondId)
                .orElse(null);

        if (portfolio == null) return;

        int oldQty = portfolio.getQuantity();
        if (oldQty < quantity) return;

        int newQty = oldQty - quantity;

        if (newQty == 0) {
            portfolio.setQuantity(0);
            portfolio.setAveragePrice(0.0);
        } else {
            portfolio.setQuantity(newQty);
        }

        portfolioRepository.save(portfolio);
    }


    @Override
    @Transactional
    public void updatePortfolio(int id, PortfolioDto portfolioDto) {
        Portfolio portfolio = portfolioRepository.findById(id).orElse(null);
        if (portfolio == null) return;

        portfolio.setQuantity(portfolioDto.getQuantity());
        portfolio.setAveragePrice(portfolioDto.getAveragePrice());

        portfolioRepository.save(portfolio);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PortfolioDto> getPortfolioByBondId(int bondId) {
        List<Portfolio> portfolios = portfolioRepository.findByBond_BondId(bondId);
        if (portfolios.isEmpty()) {
            throw new BondNotFoundException(bondId);
        }
        return portfolios.stream()
                .map(PortfolioMapper::toDto)
                .toList();
    }


//    new added
    @Override
    public List<PortfolioDto> getAllPortfolios() {
        return portfolioRepository.findAll()
                .stream()
                .map(p -> {
                    PortfolioDto dto = new PortfolioDto();
                    dto.setPortfolioId(p.getPortfolioId());
                    dto.setUserId(p.getUser().getUserId());
                    dto.setBondId(p.getBond().getBondId());
                    dto.setQuantity(p.getQuantity());
                    dto.setAveragePrice(p.getAveragePrice());
                    return dto;
                })
                .toList();
    }


}