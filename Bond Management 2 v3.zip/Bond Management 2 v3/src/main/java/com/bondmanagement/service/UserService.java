package com.bondmanagement.service;

import com.bondmanagement.entity.User;

public interface UserService {
    User getUserDetails(long userId);
    boolean existUser(long userId);
    void addUser(User user);
    public void deleteUserById(long id);
}
