package com.bondmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bondmanagement.entity.User;
import com.bondmanagement.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserRepository userRepository;
	
	public User getUserDetails(long userId){
		return userRepository.findById(userId).orElse(null);
	}

    public boolean existUser(long userId){
        return userRepository.existsById(userId);
    }

    public void addUser(User user){
        userRepository.save(user);
    }

    public void deleteUserById(long id){
        userRepository.deleteById(id);
    }
}
