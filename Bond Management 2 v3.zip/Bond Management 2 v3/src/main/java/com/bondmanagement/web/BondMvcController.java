package com.bondmanagement.web;

import com.bondmanagement.dto.BondDto;
import com.bondmanagement.service.BondService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/ui/bonds")
public class BondMvcController {

    private final BondService bondService;

    public BondMvcController(BondService bondService) {
        this.bondService = bondService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("bonds", bondService.getAllBonds());
        return "bonds/list";
    }

    @GetMapping("/new")
    public String createForm(Model model) {
        BondDto dto = new BondDto();
        dto.setStatus(BondDto.Status.ACTIVE);
        model.addAttribute("bond", dto);
        model.addAttribute("statuses", BondDto.Status.values());
        return "bonds/form";
    }

    @PostMapping
    public String create(@ModelAttribute("bond") @Valid BondDto bond, BindingResult br, Model model) {
        if (br.hasErrors()) {
            model.addAttribute("statuses", BondDto.Status.values());
            return "bonds/form";
        }
        bondService.addBond(bond);
        return "redirect:/ui/bonds";
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable int id, Model model) {
        BondDto dto = bondService.getBondDetails(id);
        if (dto == null) return "redirect:/ui/bonds";
        model.addAttribute("bond", dto);
        model.addAttribute("statuses", BondDto.Status.values());
        return "bonds/form";
    }

    @PostMapping("/{id}")
    public String update(@PathVariable int id, @ModelAttribute("bond") @Valid BondDto bond, BindingResult br, Model model) {
        if (br.hasErrors()) {
            model.addAttribute("statuses", BondDto.Status.values());
            return "bonds/form";
        }
        bondService.updateBond(id, bond);
        return "redirect:/ui/bonds";
    }
}