package com.bondmanagement.web;

import com.bondmanagement.service.BondService;
import com.bondmanagement.service.ComplianceLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/ui/compliance")
public class ComplianceMvcController {

    private final ComplianceLogService complianceLogService;
    private final BondService bondService;

    @Autowired
    public ComplianceMvcController(ComplianceLogService complianceLogService,BondService bondService) {
        this.complianceLogService = complianceLogService;
        this.bondService = bondService;
    }

    @GetMapping
    public String page(@RequestParam(name = "orderId", required = false) Integer orderId, Model model) {
        model.addAttribute("orderId", orderId);
        if (orderId != null) {
            model.addAttribute("logs", complianceLogService.getComplianceReport(orderId));
        }

        // Always add all logs for the global list
        model.addAttribute("allLogs", complianceLogService.getAllLogs());

        // Add pending orders separately
        model.addAttribute("pendingOrders", complianceLogService.getPendingOrders());

        return "compliance/page";
    }


    @PostMapping("/validate")
    public String validate() {
        complianceLogService.validateOrder();
        return "redirect:/ui/compliance";
    }
//  added to execute bond order one at a time
    @PostMapping("/{orderId}/execute")
    public String executeOrder(@PathVariable int orderId) {
        complianceLogService.executeOrder(orderId);
        return "redirect:/ui/compliance";
    }



    //  added to reject bond order at a time
    @PostMapping("/{orderId}/reject")
    public String rejectOrder(@PathVariable int orderId) {
        complianceLogService.rejectOrder(orderId);
        return "redirect:/ui/compliance";
    }

    @GetMapping("/order/{orderId}/bond")
    public String bondDetails(@PathVariable int orderId, Model model) {
        // Get the order first
        var orderOpt = complianceLogService.getOrderById(orderId);
        if (orderOpt == null) {
            return "redirect:/ui/compliance"; // fallback if order not found
        }

        var order = orderOpt.getBond();
        var bond = bondService.getBondDetails(order.getBondId());

        model.addAttribute("order", order);
        model.addAttribute("bond", bond);

        return "compliance/bond-details";
    }


}