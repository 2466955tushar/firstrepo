package com.bondmanagement.web;

import com.bondmanagement.security.CurrentUserService;
import com.bondmanagement.service.CouponService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/ui/coupons")
public class CouponMvcController {

    private final CouponService couponService;
    private final CurrentUserService currentUserService;

    public CouponMvcController(CouponService couponService,CurrentUserService currentUserService) {
        this.currentUserService = currentUserService;
        this.couponService = couponService;
    }

    @GetMapping
    public String history(@RequestParam(name = "bondId", required = false) Integer bondId,
                          Model model) {
        long userId = currentUserService.currentUserId();

        if (bondId != null) {
            var coupons = couponService.getCouponHistory(bondId);
            model.addAttribute("bondId", bondId);
            model.addAttribute("coupons", coupons);
            model.addAttribute("hasCoupons", coupons != null && !coupons.isEmpty());
        } else {
            var coupons = couponService.getAllCouponsForUser(userId);
            model.addAttribute("coupons", coupons);
            model.addAttribute("hasCoupons", coupons != null && !coupons.isEmpty());
        }

        return "coupons/list";
    }

//    @GetMapping
//    public String history(@RequestParam(name = "bondId", required = false) Integer bondId, Model model) {
//        model.addAttribute("bondId", bondId);
//
//        if (bondId != null) {
//            var coupons = couponService.getCouponHistory(bondId);
//            model.addAttribute("coupons", coupons);
//            model.addAttribute("hasCoupons", coupons != null && !coupons.isEmpty());
//        } else {
//            model.addAttribute("hasCoupons", false);
//        }
//
//        return "coupons/list";
//    }

    @PostMapping("/schedule")
    public String schedule(@RequestParam int bondId) {
        // Option A: prevent duplicates by not scheduling if already scheduled
        var existing = couponService.getCouponHistory(bondId);
        if (existing == null || existing.isEmpty()) {
            couponService.scheduleCouponPayment(bondId);
        }
        return "redirect:/ui/coupons?bondId=" + bondId;
    }


}