package com.bondmanagement.web;

import com.bondmanagement.dto.OrderDto;
import com.bondmanagement.entity.Order;
import com.bondmanagement.mapper.OrderMapper;
import com.bondmanagement.security.CurrentUserService;
import com.bondmanagement.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@Controller
@RequestMapping("/ui/orders")
public class OrderMvcController {

    private final OrderService orderService;
    private final CurrentUserService currentUserService;

    public OrderMvcController(OrderService orderService, CurrentUserService currentUserService) {
        this.orderService = orderService;
        this.currentUserService = currentUserService;
    }

    @GetMapping("/new")
    public String placeOrderForm(@RequestParam(name = "bondId", required = false) Integer bondId,
                                 @RequestParam(name = "faceValue", required = false) Double faceValue,
                                 Model model) {
        OrderDto dto = new OrderDto();
        dto.setOrderType(OrderDto.OrderType.BUY);

        if (bondId != null) {
            dto.setBondId(bondId);
        }

        model.addAttribute("order", dto);
        model.addAttribute("types", OrderDto.OrderType.values());
        model.addAttribute("faceValue", faceValue);
        return "orders/form";
    }

    @PostMapping
    public String placeOrder(@ModelAttribute("order") @Valid OrderDto order, BindingResult br, Model model) {
        if (br.hasErrors()) {
            model.addAttribute("types", OrderDto.OrderType.values());
            return "orders/form";
        }

        // force logged-in user
        order.setUserId(currentUserService.currentUserId());

        orderService.placeOrder(order);
        return "redirect:/ui/orders/status";
    }

    @PostMapping("/{id}/cancel")
    public String cancel(@PathVariable int id) {
        orderService.cancelOrder(id);
        return "redirect:/ui/orders/status";
    }

    // find all order of a single user
    //  -- change the status page to also show list of Orders and Added the Search option as well
    @GetMapping("/status")
    public String listUserOrders(@RequestParam(name = "orderId", required = false) Integer orderId,
                                 Model model) {
        long userId = currentUserService.currentUserId();
        System.out.println("Listing orders for userId=" + userId);

        List<Order> orders = orderService.findByUserId(userId);

        // If a specific orderId was searched, filter the list
        if (orderId != null) {
            orders = Collections.singletonList(OrderMapper.toEntity(orderService.findByUserIdAndOrderId(userId, orderId)));
            model.addAttribute("searchedOrderId", orderId);
        }

        // Flag if any order is pending
        boolean hasPending = orders.stream()
                .anyMatch(o -> o.getStatus() == Order.Status.PENDING);

        model.addAttribute("hasPending", hasPending);
        model.addAttribute("orders", orders);

        return "orders/status"; // template
    }



}