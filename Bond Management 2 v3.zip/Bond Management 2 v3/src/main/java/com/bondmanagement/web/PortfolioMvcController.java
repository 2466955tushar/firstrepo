package com.bondmanagement.web;

import com.bondmanagement.dto.PortfolioDto;
import com.bondmanagement.entity.Portfolio;
import com.bondmanagement.security.CurrentUserService;
import com.bondmanagement.service.PortfolioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/ui/portfolios")
public class PortfolioMvcController {

    private final PortfolioService portfolioService;
    private final CurrentUserService currentUserService;

    public PortfolioMvcController(PortfolioService portfolioService, CurrentUserService currentUserService) {
        this.portfolioService = portfolioService;
        this.currentUserService = currentUserService;
    }

//    changed the view to only show list of protfolios
    @GetMapping()
    public String view(@RequestParam(name = "bondId", required = false) Integer bondId,
                       Model model) {
        model.addAttribute("bondId", bondId);

        if (bondId != null) {
            // Show holdings filtered by bondId
            model.addAttribute("rows", portfolioService.getPortfolioByBondId(bondId));
        } else {
            // Show all holdings
            model.addAttribute("rows", portfolioService.getAllPortfolios());
        }

        return "portfolios/list";
    }


//    @GetMapping
//    public String view(Model model) {
//        model.addAttribute("rows", portfolioService.getAllPortfolios());
//        return "portfolios/list";
//    }
//
//
//    @GetMapping("/add")
//    public String addForm() {
//        return "portfolios/add";
//    }
//
//    @PostMapping("/add")
//    public String add(@RequestParam int bondId, @RequestParam int qty) {
//        long userId = currentUserService.currentUserId();
//        portfolioService.addPortfolio(bondId, userId, qty);
//        return "redirect:/ui/portfolios?bondId=" + bondId;
//    }
//
//    @GetMapping("/{id}/edit")
//    public String editForm(@PathVariable int id, Model model) {
//        PortfolioDto dto = new PortfolioDto();
//        dto.setPortfolioId(id);
//        model.addAttribute("portfolio", dto);
//        return "portfolios/form";
//    }
//
//    @PostMapping("/{id}")
//    public String update(@PathVariable int id, @ModelAttribute PortfolioDto portfolio) {
//        portfolioService.updatePortfolio(id, portfolio);
//        return "redirect:/ui/portfolios";
//    }
}