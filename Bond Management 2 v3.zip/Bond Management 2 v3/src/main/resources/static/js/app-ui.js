(function () {
  document.addEventListener("DOMContentLoaded", function () {
    document.body.classList.add("page-ready");
  });

  // Loader disabled: remove overlay logic
  // Toast helper (keep if you want notifications)
  window.showToast = function (title, message) {
    const toastEl = document.getElementById("appToast");
    if (!toastEl || typeof bootstrap === "undefined") return;

    toastEl.querySelector(".toast-title").textContent = title || "Info";
    toastEl.querySelector(".toast-message").textContent = message || "";

    const toast = bootstrap.Toast.getOrCreateInstance(toastEl, { delay: 2800 });
    toast.show();
  };
})();
