package com.bondmanagement.service;

import com.bondmanagement.dto.BondDto;
import com.bondmanagement.entity.Bond;
import com.bondmanagement.repository.BondRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(org.mockito.junit.jupiter.MockitoExtension.class)
class BondServiceImplTest {

    @Mock
    BondRepository bondRepository;

    @Mock
    CouponService couponService;

    @InjectMocks
    BondServiceImpl bondService;

    @Test
    void addBond_shouldSaveBond_andScheduleCoupons() {
        BondDto dto = new BondDto();
        dto.setIssuer("Govt");
        dto.setFaceValue(1000.0);
        dto.setCouponRate(5.0);
        dto.setMaturityDate(LocalDate.now().plusYears(5));
        dto.setStatus(BondDto.Status.ACTIVE);

        Bond saved = new Bond();
        saved.setBondId(10);

        when(bondRepository.save(any(Bond.class))).thenReturn(saved);

        bondService.addBond(dto);

        verify(bondRepository, times(1)).save(any(Bond.class));
        verify(couponService, times(1)).scheduleCouponPayment(10);
        verifyNoMoreInteractions(couponService);
    }

    @Test
    void getBondDetails_shouldReturnDto_whenBondExists() {
        Bond bond = new Bond();
        bond.setBondId(1);
        bond.setIssuer("Corp");
        bond.setFaceValue(1000.0);
        bond.setCouponRate(6.0);
        bond.setMaturityDate(LocalDate.now().plusYears(2));
        bond.setStatus(Bond.Status.ACTIVE);

        when(bondRepository.findById(1)).thenReturn(Optional.of(bond));

        BondDto result = bondService.getBondDetails(1);

        assertNotNull(result);
        assertEquals(1, result.getBondId());
        assertEquals("Corp", result.getIssuer());
        verify(bondRepository).findById(1);
    }

    @Test
    void getAllBonds_shouldReturnList() {
        Bond b1 = new Bond(); b1.setBondId(1);
        Bond b2 = new Bond(); b2.setBondId(2);

        when(bondRepository.findAll()).thenReturn(List.of(b1, b2));

        List<BondDto> result = bondService.getAllBonds();

        assertEquals(2, result.size());
        verify(bondRepository).findAll();
    }

    @Test
    void updateBond_shouldRescheduleCoupons_whenScheduleFieldsChanged() {
        Bond existing = new Bond();
        existing.setBondId(5);
        existing.setIssuer("Issuer");
        existing.setFaceValue(1000.0);
        existing.setCouponRate(5.0);
        existing.setMaturityDate(LocalDate.now().plusYears(3));
        existing.setStatus(Bond.Status.ACTIVE);

        BondDto update = new BondDto();
        update.setIssuer("Issuer");
        update.setFaceValue(2000.0); // changed
        update.setCouponRate(5.0);
        update.setMaturityDate(existing.getMaturityDate());
        update.setStatus(BondDto.Status.ACTIVE);

        when(bondRepository.findById(5)).thenReturn(Optional.of(existing));
        when(bondRepository.save(any(Bond.class))).thenAnswer(inv -> inv.getArgument(0));

        bondService.updateBond(5, update);

        verify(bondRepository).findById(5);
        verify(bondRepository).save(any(Bond.class));
        verify(couponService).deleteCoupons(5);
        verify(couponService).scheduleCouponPayment(5);
    }
}