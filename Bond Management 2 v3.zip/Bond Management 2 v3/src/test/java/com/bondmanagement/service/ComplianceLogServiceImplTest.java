package com.bondmanagement.service;

import com.bondmanagement.entity.Bond;
import com.bondmanagement.entity.Order;
import com.bondmanagement.entity.User;
import com.bondmanagement.repository.ComplianceLogRepository;
import com.bondmanagement.repository.OrderRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;

import java.util.List;

import static org.mockito.Mockito.*;

@ExtendWith(org.mockito.junit.jupiter.MockitoExtension.class)
class ComplianceLogServiceImplTest {

    @Mock ComplianceLogRepository complianceLogRepository;
    @Mock OrderService orderService;
    @Mock OrderRepository orderRepository;
    @Mock BondService bondService;
    @Mock UserService userService;
    @Mock PortfolioService portfolioService;

    @InjectMocks
    ComplianceLogServiceImpl complianceLogService;

    @Test
    void validateOrder_shouldExecutePendingBuyOrders_andUpdatePortfolio_andLog() {
        Order pending = new Order();
        pending.setOrderId(1);
        pending.setStatus(Order.Status.PENDING);
        pending.setOrderType(Order.OrderType.BUY);
        pending.setQuantity(2);
        pending.setPrice(100.0);

        Bond bond = new Bond();
        bond.setBondId(10);
        pending.setBond(bond);

        User user = new User();
        user.setUserId(20L);
        pending.setUser(user);

        when(orderService.findByStatus(Order.Status.PENDING)).thenReturn(List.of(pending));
        when(bondService.bondExists(10)).thenReturn(true);
        when(userService.existUser(20)).thenReturn(true);

        complianceLogService.validateOrder();

        verify(orderRepository).save(pending);
        verify(portfolioService).applyBuyTrade(10, 20L, 2, 100.0);
        verify(complianceLogRepository).save(any());
        verify(orderService, never()).deleteOrder(any());
    }
}