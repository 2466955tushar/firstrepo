package com.bondmanagement.service;

import com.bondmanagement.dto.OrderDto;
import com.bondmanagement.entity.Order;
import com.bondmanagement.repository.OrderRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(org.mockito.junit.jupiter.MockitoExtension.class)
class OrderServiceImplTest {

    @Mock
    OrderRepository orderRepository;

    @InjectMocks
    OrderServiceImpl orderService;

    @Test
    void placeOrder_shouldSetPending_andSave() {
        OrderDto dto = new OrderDto();
        dto.setBondId(1);
        dto.setUserId(2L);
        dto.setOrderType(OrderDto.OrderType.BUY);
        dto.setQuantity(10);
        dto.setPrice(99.5);

        orderService.placeOrder(dto);

        ArgumentCaptor<Order> captor = ArgumentCaptor.forClass(Order.class);
        verify(orderRepository).save(captor.capture());

        Order saved = captor.getValue();
        assertEquals(Order.Status.PENDING, saved.getStatus());
        assertEquals(Order.OrderType.BUY, saved.getOrderType());
        assertEquals(10, saved.getQuantity());
    }

    @Test
    void cancelOrder_shouldSetCancelled_whenNotAlreadyCancelled() {
        Order order = new Order();
        order.setOrderId(10);
        order.setStatus(Order.Status.PENDING);

        when(orderRepository.findById(10)).thenReturn(Optional.of(order));

        orderService.cancelOrder(10);

        assertEquals(Order.Status.CANCELLED, order.getStatus());
        verify(orderRepository).save(order);
    }

    @Test
    void getOrderStatus_shouldReturnStatusName_orNull() {
        when(orderRepository.findStatusByOrderId(1)).thenReturn(Order.Status.EXECUTED);

        String status = orderService.getOrderStatus(1);

        assertEquals("EXECUTED", status);
        verify(orderRepository).findStatusByOrderId(1);
    }
}